#ifndef __StateMachine_H_
#define __StateMachine_H_

#include "../Headers/State Machine/State.h"
// Standard C++
#include <memory>
#include <stack>

typedef std::unique_ptr<State> StateRef;

class StateMachine
{
public:
	StateMachine() { }
	~StateMachine() { }

	void AddState(StateRef newState, bool isReplacing = true, bool isReplacingAll = false);
	void RemoveState();
	// Run at start of each loop in Game.cpp
	void ProcessStateChanges();

	StateRef &GetActiveState();

private:
	// All states
	std::stack<StateRef> states;
	// New added state
	StateRef newState;

	bool isRemoving;
	bool isAdding;
	bool isReplacing;
	bool isReplacingAll;
};

#endif 