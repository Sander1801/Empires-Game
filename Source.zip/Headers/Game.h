#pragma once

#include <stdio.h>
#include <assert.h>
#include <math.h>
#include <sys/time.h>
#include "FileLoader.h"
#include <vector>

#include "Graphics.h"
#include "../Headers/KeyboardInput.h"

// Include GLM
#undef countof
#include "glm/glm/glm.hpp"
#include "glm/glm/gtc/matrix_transform.hpp"
#undef countof


class Game
{
public:
	Game();
	~Game();
	
	Graphics* MyGraphics;  // create a 1 time instance of a graphics class;
		
	FileLoader	Handler;
	
	cKeyboard keyboard;
	uint32_t	ScreenX, ScreenY;


	bool	Init(Graphics* Graph);
	bool	Update();
	
		
};



