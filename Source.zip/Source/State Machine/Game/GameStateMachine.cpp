#include "../Headers/State Machine/Game/GameStateMachine.h"
// Standard C++
#include <iostream>

void StateMachine::AddState(StateRef newState, bool isReplacing, bool isReplacingAll)
{
	this->isRemoving = false;
	this->isAdding = true;
	this->isReplacing = isReplacing;
	this->isReplacingAll = isReplacingAll;

	// Set new state
	this->newState = std::move(newState);
}

void StateMachine::RemoveState()
{
	this->isRemoving = true;
}

void StateMachine::ProcessStateChanges()
{
	// State is not empty and needs to be removed
	if (this->isRemoving && !this->states.empty())
	{
		// Remove latest state
		this->states.pop();

		// There are more states
		if (!this->states.empty())
		{
			// Resume latest state
			this->states.top()->Resume();
		}
		// Stop removing
		this->isRemoving = false;
	}

	if (this->isAdding)
	{
		// State is not empty
		if (!this->states.empty())
		{
			// Replace all states
			if (this->isReplacingAll)
			{
				while (!this->states.empty())
				{
					this->states.pop();
				}
			}
			// Replace previous state
			else if (this->isReplacing)
			{
				this->states.pop();
			}
			// Set previous state on pause
			else
			{
				this->states.top()->Pause();
			}
		}

		// Push new state
		this->states.push(std::move(this->newState));
		// Get last inserted element and call Init
		this->states.top()->OnEnter();
		// Stop adding the state
		this->isAdding = false;
	}
}

StateRef &StateMachine::GetActiveState()
{
	// Get last inserted element
	return this->states.top();
}