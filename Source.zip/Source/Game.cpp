#include "../Headers/Game.h"

/* Our Game class is going to take responsibility for the game code
 * 
 *
 *
 *
 **/

Game::Game()
{
}

Game::~Game()
{
} 


bool Game::Init(Graphics* Gr)
{ 
	MyGraphics = Gr;
}

bool Game::Update()
{	
// we're going to keep track of time so need some structures to hold the time in linux's strange format
	struct timeval t1, t2;
	struct timezone tz;
	float deltatime;
	float totaltime = 0.0f;
	unsigned int frames = 0;

	gettimeofday(&t1, &tz);
	int Counter = 0;
	while (Counter++ < 2000)
	{
		if (keyboard.getKeyState(KEY_ENTER)) {
			printf("%4d", KEY_ENTER);
		}

		gettimeofday(&t2, &tz);
		deltatime = (float)(t2.tv_sec - t1.tv_sec + (t2.tv_usec - t1.tv_usec) * 0.0000001f);
		t1 = t2;
	
		// Clear the color buffer
		glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
		
		// after our draw we need to swap buffers to display on screen
		eglSwapBuffers(MyGraphics->state.display, MyGraphics->state.surface);
		
// now work out how long that took
		totaltime += deltatime;
		frames++;
		if (totaltime >  1.0f)
		{
			//printf("%4d frames rendered in %1.4f seconds -> FPS=%3.4f\n", frames, totaltime, frames / totaltime);
			totaltime -= 1.0f;
			frames = 0;
		}
	}
	
	

}
