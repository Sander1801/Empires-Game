#include "../Headers/State Machine/Game/GameStateMachine.h"

struct GameData
{
	GameStateMachine machine;
};

// Reference of GameData
typedef std::shared_ptr<GameData> GameDataRef;