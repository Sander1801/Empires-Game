#pragma once

#define Debug true

// Other stuff like DB password, et cetera...