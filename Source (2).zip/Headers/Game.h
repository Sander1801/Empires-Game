#pragma once

#include "../Headers/Graphics/Graphics.h"

class Game
{
public:
	Game();
	~Game();
	
	bool OnEnter(Graphics* Graph);
	bool OnUpdate();

private:
	Graphics* m_Graphics;
};



