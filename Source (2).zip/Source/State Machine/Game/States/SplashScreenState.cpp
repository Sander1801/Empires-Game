#include "../Headers/State Machine/Game/States/SplashScreenState.h"

SplashScreenState::SplashScreenState(GameDataRef a_GameStateData) :
	m_GameStateData(a_GameStateData)
{
}

void SplashScreenState::OnEnter()
{
}

void SplashScreenState::OnUpdate(float a_fDeltaTime)
{
}

void SplashScreenState::OnDraw()
{
}

void SplashScreenState::OnExit()
{
}
