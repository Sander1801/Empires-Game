#include "../Headers/Game.h"

// Standard C++
#include <stdio.h>
#include <math.h>
#include <sys/time.h>
#include <iostream>

#define UPDATE_DELTA_TIME 1.f / 30.f // Update the gameplay with 30 frames per second.

Game::Game()
{
}

Game::~Game()
{
} 


bool Game::OnEnter(Graphics* a_Graphics)
{ 
	m_Graphics = a_Graphics;
}

bool Game::OnUpdate()
{	
	// FPS Info
	unsigned int uiFrames = 0;
	float fDeltatime = 0.0f;
	float fTotaltime = 0.0f;
	float fAccumulator = 0.0f;
	struct timeval TimeVal1, TimeVal2;
	struct timezone TimeZone;

	gettimeofday(&TimeVal1, &TimeZone);

	while (true)
	{
		gettimeofday(&TimeVal2, &TimeZone);
		fDeltatime = (float)(TimeVal2.tv_sec - TimeVal1.tv_sec + (TimeVal2.tv_usec - TimeVal1.tv_usec) * 0.0000001f);
		TimeVal1 = TimeVal2;

		// Now work out how long that took
		fTotaltime += fDeltatime;
		fAccumulator += fDeltatime;
		uiFrames++;

		// Clear the color buffer
		glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
		
		// After our draw we need to swap buffers to display on screen
		eglSwapBuffers(m_Graphics->state.display, m_Graphics->state.surface);

		// Update the gameplay
		while (fAccumulator >= UPDATE_DELTA_TIME)
		{
			// Update the gameplay

			fAccumulator -= UPDATE_DELTA_TIME;
		}

		// Draw the gameplay


		if (fTotaltime > 1.0f)
		{
			std::cout << "FPS: " << uiFrames / fTotaltime << " - " << test << " - " << test2 << std::endl;

			fTotaltime -= 1.0f;
			uiFrames = 0;
		}
	}
}