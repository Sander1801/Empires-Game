#pragma once

#define Debug true // _Debug doesn't work with gcc.

// Other stuff like DB password, et cetera...