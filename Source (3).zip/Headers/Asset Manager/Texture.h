#ifndef __TEXTURE_H
#define __TEXTURE_H

#include <string>

struct Texture 
{
	unsigned int ID;
	std::string sType;
	std::string sPath;
};

#endif